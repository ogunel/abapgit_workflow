---
title: Proxy configuration
category: setup
order: 20
---

Online projects only

If your server is behind a proxy, it can be configured under Advanced -> Settings,
![](img/proxy.png)

**Hint:** the URL must **not contain https://** -> just enter name or IP
