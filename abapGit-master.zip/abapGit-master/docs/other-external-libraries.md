---
title: External Libraries
category: other
order: 45
---

abapGit uses a few external libraries, these are loaded via [cdnjs](https://cdnjs.com/about)

Library   | Version | License
:------------ | :------------ | :------------
[octicons](https://github.com/primer/octicons) | 4.4.0 | MIT
[gitgraph](https://github.com/nicoespeon/gitgraph.js) | 1.14.0 | MIT
